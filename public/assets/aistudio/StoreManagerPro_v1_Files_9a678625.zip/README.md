# Store Manager Pro — Corrected Baseline Package

## Contents
- `Final_Engineering_Baseline.md` — consolidated engineering baseline.
- `canonical_schema.sql` — executable 55-table SQLite schema.
- `seed_data.sql` — safe first-run seed; no default admin password or active placeholder license.
- `verify_canonical_schema.py` — repeatable 59-case SQL verification suite.
- `verification_results.txt` — output from the latest run in this environment.
- `extra_integrity.sql` — supplemental SQL source incorporated into the canonical schema.
- `ERD.md` — Mermaid relationship diagrams.
- `IMPLEMENTATION_CONTRACTS.md` — required Windows/Ktor/Android behavior not enforced by SQLite alone.
- `schema_crosswalk.md` — available C2-to-Canonical name mapping.
- `FINAL_CLOSURE_REPORT.md` — scope, fixes, evidence and remaining platform tests.

## Verify
Requires Python 3.10+ with its standard `sqlite3` module. The Ed25519 smoke test additionally uses `cryptography`.

```bash
python -m pip install -r requirements.txt
python verify_canonical_schema.py
```

Expected current result: 59 PASS / 0 FAIL / 0 NOT RUN. The runtime printed by the script is authoritative for that run. The checked run in this package used SQLite 3.46.1. SQLite 3.40.1 compatibility has not been independently exercised here.

## Important boundaries
- This is a Fresh Production Baseline v1. Do not run it over an existing C2 database containing data.
- SQLite does not perform Ed25519 verification, HTTPS, Android Keystore access, filesystem backup, Ktor networking or UI rendering. See `IMPLEMENTATION_CONTRACTS.md`.
- The walk-in cash-sale flow and all platform integration tests remain required before enabling those functions in a production build.
