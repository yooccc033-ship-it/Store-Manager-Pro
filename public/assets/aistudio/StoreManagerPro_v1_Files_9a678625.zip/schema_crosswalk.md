# Store Manager Pro — C2 to Canonical Schema Crosswalk

## Scope and source accuracy

This crosswalk uses the exact **42-table C2 list** recorded in the reviewed project material and compares it with the 55-table Canonical Fresh Baseline. It does not claim to be a three-way C2 / C2-R1 Supplemental / Canonical crosswalk: the complete C2-R1 Supplemental DDL was not included in the current upload set, so a row-by-row mapping to that intermediate schema cannot be independently reconstructed here.

## Summary

| Measure | Count |
|---|---:|
| C2 original tables | 42 |
| Canonical tables | 55 |
| Same-name tables | 29 |
| C2 names retired / transformed | 13 |
| Canonical names absent from C2 | 26 |

## Same-name continuity (29)

`audit_logs`, `backup_history`, `cash_movements`, `categories`, `device_pairing_pins`, `document_sequences`, `expenses`, `inventory_balances`, `inventory_movements`, `inventory_quotas`, `payment_allocations`, `payments`, `products`, `purchase_items`, `purchase_receipt_items`, `purchase_receipts`, `purchases`, `registered_devices`, `sale_items`, `sale_return_items`, `sale_returns`, `sales`, `stock_items`, `stores`, `unit_conversions`, `units_of_measure`, `user_sessions`, `users`, `warehouses`.

## Renamed, split, merged or replaced (13)

| C2 table | Canonical destination | Treatment |
|---|---|---|
| `attribute_definitions` | `product_variants.attributes_json` | Variant attributes are stored as structured JSON in the variant entity in v1. |
| `cash_sessions` | `cash_shifts` + `cash_registers` | Session lifecycle separated from the physical/logical register. |
| `financial_ledger` | `party_ledger_entries` | Unified ledger entries now carry explicit party kind and source-document identity. |
| `idempotent_requests` | `idempotency_records` | Device/tenant-scoped idempotency key and response lifecycle. |
| `parties` | `customers` + `suppliers` | Split to enforce distinct business roles and credit semantics. |
| `sale_item_quota_allocations` | `sale_item_quota_deductions` | Explicit quantity deduction from a signed device quota. |
| `stock_audit_items` | `inventory_adjustment_lines` | Physical count and variance line. |
| `stock_audits` | `inventory_adjustments` | Draft/post/cancel adjustment header. |
| `stock_item_attributes` | `product_variants.attributes_json` | Variant attributes consolidated; not a general EAV table. |
| `supplier_return_items` | `purchase_return_items` | Supplier return lines use the purchase-return lifecycle. |
| `supplier_returns` | `purchase_returns` | Supplier returns use an explicit purchase source and return workflow. |
| `system_license` | `app_licenses` | License metadata is tenant-scoped and signature-bearing. |
| `user_permissions` | `roles`, `permissions`, `role_permissions`, `user_roles` | Normalized RBAC model. |

## Canonical entities absent by name in C2 (26)

`app_licenses`, `cash_registers`, `cash_shifts`, `currencies`, `customer_groups`, `customers`, `exchange_rates`, `expense_categories`, `fiscal_years`, `idempotency_records`, `inventory_adjustment_lines`, `inventory_adjustments`, `party_ledger_entries`, `permissions`, `price_list_items`, `price_lists`, `product_variants`, `purchase_return_items`, `purchase_returns`, `role_permissions`, `roles`, `sale_item_quota_deductions`, `suppliers`, `tax_rates`, `tenants`, `user_roles`.

## Migration decision

Canonical is **Fresh Production Baseline v1.0**. There is no C2-to-Canonical production migration in this package. Old C2 table names are documented for design provenance only; do not run a rename/backfill migration against production data on the strength of this crosswalk. If a real deployed C2 database is later discovered, its exact DDL and data sample must be supplied and a separate preservation migration must be designed and tested.
